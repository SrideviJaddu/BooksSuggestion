package com.example.srkrtc.asynctaskbook;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
   // TextView name,author;
    EditText book_name;
   // ImageView iv;
    FetchBookData fetchBookData;
    List<Data> dataList;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //name=(TextView)findViewById(R.id.name);
        //author=(TextView)findViewById(R.id.author);
        book_name=(EditText)findViewById(R.id.book_name);
        //iv=(ImageView)findViewById(R.id.image);
        dataList=new ArrayList<Data>();
        recyclerView=(RecyclerView)findViewById(R.id.recyclerview);
    }

    public void fetchdata(View view) {
        String book=book_name.getText().toString();
        fetchBookData=new FetchBookData(this,recyclerView,dataList);
        fetchBookData.execute(book);
    }
}
