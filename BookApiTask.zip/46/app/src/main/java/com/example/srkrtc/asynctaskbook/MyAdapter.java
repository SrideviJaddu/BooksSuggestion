package com.example.srkrtc.asynctaskbook;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by srkrtc on 2/24/2018.
 */

class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
    Context ct;
    //TextView title,author;
    List<Data> dataList;
    public MyAdapter(Context ct, List<Data> dataList) {
        this.ct=ct;
        this.dataList=dataList;


    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.data_item,parent,false);
        return new ViewHolder(v);
            }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.title.setText(dataList.get(position).getTitle());
        holder.author.setText(dataList.get(position).getAuthor());
        Picasso.with(ct).load(dataList.get(position).getImg()).into(holder.iv);

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title,author;
        ImageView iv;
        public ViewHolder(View itemView) {
            super(itemView);
            iv=(ImageView)itemView.findViewById(R.id.image);

            title=(TextView)itemView.findViewById(R.id.title);
            author=(TextView)itemView.findViewById(R.id.author);
        }
    }
}
