package com.example.srkrtc.asynctaskbook;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

/**
 * Created by srkrtc on 2/23/2018.
 */

public class FetchBookData extends AsyncTask<String,Integer,String> {
   //TextView name,author;
   //ImageView iv;
   Context ct;
   RecyclerView recyclerView;
   ProgressDialog pd;
   List<Data>dataList;
    public FetchBookData(MainActivity mainActivity, RecyclerView recyclerView, List<Data> dataList) {
       // this.name=name;
        //this.iv=iv;
        //this.author=author;
        this.ct=mainActivity;
        this.dataList=dataList;
        this.recyclerView=recyclerView;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        pd=new ProgressDialog(ct);
        pd.setTitle("please wait");
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pd.show();
    }

    @Override
    protected String doInBackground(String... strings) {
        String book_name=strings[0];
        String Url="https://www.googleapis.com/books/v1/volumes?q="+book_name;
        try {
            URL url1=new URL(Url);
            HttpURLConnection connection= (HttpURLConnection) url1.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();
            InputStream is=connection.getInputStream();
            StringBuilder builder=new StringBuilder();
            BufferedReader reader=new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line=reader.readLine())!=null)
            {
                builder.append(line);
            }
            return builder.toString();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

        try {
            JSONObject jsonObject=new JSONObject(s);
            JSONArray items=jsonObject.getJSONArray("items");
            for (int i=0;i<items.length();i++){
                Data currentdata=new Data();
                JSONObject position=items.getJSONObject(i);
                JSONObject info=position.getJSONObject("volumeInfo");
                String title=info.getString("title");
                JSONArray authors_array=info.getJSONArray("authors");
                String author_name=authors_array.getString(0);
                JSONObject image=info.getJSONObject("imageLinks");
                String book_image=image.getString("thumbnail");
                Toast.makeText(ct,""+title+"\n"+author_name+"\n"+book_image,Toast.LENGTH_SHORT).show();
                //name.setText(title);
                //author.setText(author_name);
               // Picasso.with(ct).load(book_image).into(iv);
                currentdata.setTitle(title);
                currentdata.setAuthor(author_name);
                currentdata.setImg(book_image);
                dataList.add(currentdata);
                recyclerView.setLayoutManager(new LinearLayoutManager(ct));
                recyclerView.setAdapter(new MyAdapter(ct,dataList));

            }


        } catch (JSONException e) {
            e.printStackTrace();
        }
        pd.dismiss();
    }
}
