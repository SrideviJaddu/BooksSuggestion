package com.example.srkrtc.asynctaskbook;

/**
 * Created by srkrtc on 2/24/2018.
 */

public class Data {
    String title;
    String author;
    String img;
    public Data(){}

    public String getTitle() {
        return title;
    }        //alt+insert select getter and setter

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public Data(String title, String author, String img) {

        this.title = title;
        this.author = author;
        this.img = img;
    }
}
